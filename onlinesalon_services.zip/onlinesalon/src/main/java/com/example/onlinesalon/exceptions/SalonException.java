package com.example.onlinesalon.exceptions;

public class SalonException extends Exception{
	public SalonException(String msg) {
		super(msg);
	}

}
