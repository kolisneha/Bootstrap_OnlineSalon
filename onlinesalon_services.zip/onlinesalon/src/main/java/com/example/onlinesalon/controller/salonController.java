package com.example.onlinesalon.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.onlinesalon.exceptions.SalonException;
import com.example.onlinesalon.model.Salon;
import com.example.onlinesalon.service.SalonService;

@RestController
@CrossOrigin(value = "http://localhost:3000/")
@RequestMapping("api")
public class salonController {
	@Autowired
	private SalonService salonservice;
	
	@PostMapping("newsalonservice")
	public Salon addService( @Valid @RequestBody Salon salon) {
		return this.salonservice.addService(salon);
	}
	
	@DeleteMapping("salon/{serviceId}")
	public Salon removeService(@PathVariable("serviceId")  String serviceId) throws SalonException {
		
		return this.salonservice.removeService(serviceId);
	}
	
	@PutMapping("updateservice")
	public Salon updateService(@Valid @RequestBody Salon salon) {
		return this.salonservice.updateService(salon);
	}
	
	@GetMapping("getservice/{serviceId}")
	public Salon getService(@PathVariable String serviceId) throws SalonException {
		return this.salonservice.getService(serviceId);
	}
	
	@GetMapping("allservices")
	public List<Salon> getAllServices() {
		return this.salonservice.getAllServices();
	}
	@GetMapping("servicesbyprice")
	public List<Salon>  getServiceByPrice( ) {
		return this.salonservice.getServiceByPrice();
		
	}

}
