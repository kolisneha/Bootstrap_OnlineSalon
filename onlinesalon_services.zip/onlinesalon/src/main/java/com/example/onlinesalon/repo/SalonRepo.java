package com.example.onlinesalon.repo;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.onlinesalon.model.Salon;

@Repository
public interface SalonRepo extends MongoRepository<Salon, String> {

	Optional<Salon> findByPrice(double d);

}
