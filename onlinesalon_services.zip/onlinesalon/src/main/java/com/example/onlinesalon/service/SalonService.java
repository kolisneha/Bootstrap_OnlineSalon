package com.example.onlinesalon.service;

import java.util.List;

import com.example.onlinesalon.exceptions.SalonException;
import com.example.onlinesalon.model.Salon;

public interface SalonService {
	 Salon addService(Salon salon);
	 Salon removeService(String serviceId) throws SalonException;
	 Salon updateService(Salon salon);
	 Salon getService(String serviceId) throws SalonException;
	 List<Salon> getAllServices();
	 List<Salon> getServiceByPrice();

}
