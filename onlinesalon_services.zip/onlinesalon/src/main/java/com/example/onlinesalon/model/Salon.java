package com.example.onlinesalon.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Salon {
	@Id
	String serviceId;
	
	@NotBlank(message = "Service name can't be Blank.")
	@Size(min=3,max=25,message ="ServiceName should be min of 3 chars & max of 25 chars.")
	String serviceName;
	
	@NotNull(message = "Price can't be NULL.")
	double price;
	
	@NotNull(message = "Discount can't be NULL.")
	int discount;
	
	public Salon(String serviceId, String serviceName, double price, int discount) {
		super();
		this.serviceId = serviceId;
		this.serviceName = serviceName;
		this.price = price;
		this.discount = discount;
	}
	public Salon() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	

}
