package com.example.onlinesalon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinesalonApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinesalonApplication.class, args);
	}

}
