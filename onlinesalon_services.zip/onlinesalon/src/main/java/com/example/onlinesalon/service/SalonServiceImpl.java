package com.example.onlinesalon.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.onlinesalon.exceptions.SalonException;
import com.example.onlinesalon.model.Salon;
import com.example.onlinesalon.repo.SalonRepo;

@Service
public class SalonServiceImpl implements SalonService {

	@Autowired
	private SalonRepo salonRepo;

	@Override
	public Salon addService(Salon salon) {
		// TODO Auto-generated method stub
		
		return this.salonRepo.save(salon);
	}

	@Override
	public Salon removeService(String serviceId) throws SalonException {
		
	Optional<Salon> sal=this.salonRepo.findById(serviceId);
	if(sal.empty() == null)
		throw new SalonException("Service is not available to delete");
	this.salonRepo.deleteById(serviceId);
	return sal.get();
	}

	@Override
	public Salon updateService( Salon salon) {
		// TODO Auto-generated method stub
		return this.salonRepo.save(salon);
	}

	@Override
	public Salon getService(String serviceId) throws SalonException {
		// TODO Auto-generated method stub
		Optional<Salon> sal=this.salonRepo.findById(serviceId);
		if(sal.empty() == null)
			throw new SalonException("Service is not available. Create now!!");
		return sal.get();
	}

	@Override
	public List<Salon> getAllServices() {
		// TODO Auto-generated method stub
		return salonRepo.findAll();
	}

	
	@Override
	public List<Salon>  getServiceByPrice( ) {
	//	Optional<Salon> sal=this.salonRepo.findById(Id);
		// TODO Auto-generated method stub
		//List array= getAllServices(); 	//	ArrayList pricelist=new ArrayList<Double>();
		List<Salon> allservices=this.salonRepo.findAll();
		List<Salon> returnservice=new ArrayList<Salon>();;
		double[] arr=new double[allservices.size()];
		String[] namearr=new String[allservices.size()];
		int i=0;
		for(Salon saloon:allservices)
		{
			arr[i]= saloon.getPrice();
			namearr[i]=saloon.getServiceName();
			i++;
		}
		Arrays.sort(namearr);
		Arrays.sort(arr);
		
		for(int j=0;j<allservices.size();j++)
		{
			
			Optional<Salon> optsal=this.salonRepo.findByPrice(arr[j]);
			Salon sall=optsal.get();
			returnservice.add(sall);
		}
		return returnservice;
		//return salonRepo.findAll().sort(array.get(0));
	}
	
	/*List<Salon> allservices=this.salonRepo.findAll();
		List<Salon> returnservice=new ArrayList<Salon>();;
		double[] arr=new double[allservices.size()];
		String[] namearr=new String[allservices.size()];
		int i=0;
		for(Salon saloon:allservices)
		{
			arr[i]= saloon.getPrice();
			namearr[i]=saloon.getServiceName();
			i++;
		}
		Arrays.sort(namearr);
		Arrays.sort(arr);
		
		for(int j=0;j<allservices.size();j++)
		{
			
			Optional<Salon> optsal=this.salonRepo.findByPrice(arr[j]);
			if(arr[j]==arr[j+1])
			{}
			Salon sall=optsal.get();
			returnservice.add(sall);
		}
		return returnservice;
	*/

}
