package com.example.onlinesalon;


import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.onlinesalon.exceptions.SalonException;
import com.example.onlinesalon.model.Salon;
import com.example.onlinesalon.service.SalonService;

@SpringBootTest
class OnlinesalonApplicationTests {
	@Autowired
	private SalonService salonserv;
	
	@Test
	/*void contextLoads() {
	}*/
	
	public void createServiceTest() throws SalonException {
		Salon sal=new Salon("tid", "tn", 0.0, 0);
		Salon newSal =null;
		newSal=this.salonserv.addService(sal);
		
		
		assertNotNull(newSal);
		assertNotEquals(null, newSal.getServiceId());
		
	}

	
}
