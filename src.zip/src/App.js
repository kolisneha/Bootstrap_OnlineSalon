import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';
import AddService from './Components/Salon/AddService';
import DisplayAllServices from "./Components/Salon/DisplayAllServices";
import ServicesByPrice from "./Components/Salon/ServicesByPrice";
import Layout from "./Pages/Layout";
import NoPage from "./Pages/NoPage";
import Home from "./Pages/Home";
import Modal from 'react-modal';
function App() {
  return (
    <>
     <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
          <Route index element={<Home/>} />
            <Route path="add" element={<AddService/>} />
            <Route path="display" element={<DisplayAllServices/>} />
            <Route path="byprice" element={<ServicesByPrice/>} />
            <Route path="*" element={<NoPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
