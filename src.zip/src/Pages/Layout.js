import { Outlet, Link } from "react-router-dom";

const Layout = () => {
  return (
    <>
      <nav className="navbar navbar-expand-sm  justify-content-center">
      <div><a className="navbar-brand" href="#" >Online Salon </a></div>
        <ul className="navbar-nav">
          <li className="nav-item">
            <Link className="nav-link" to="/">Home</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="add">Add New Service</Link>
          </li>
          <li className="nav-item">
            <Link  className="nav-link" to="display">Display All services</Link>
          </li>
          <li className="nav-item">
            <Link  className="nav-link" to="byprice">All services Sorted by Prices</Link>
          </li>
        </ul>
      </nav>
      <Outlet />
    </>
  )
};

export default Layout;