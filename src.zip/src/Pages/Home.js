const Home = () => {
  return (
    <>
   
<center> <h1>Heyy!! </h1> 
     <p>Welcome to our Salon!!  Book your appointment now:)</p></center>
    </>
    )
 
  };
  
export default Home;