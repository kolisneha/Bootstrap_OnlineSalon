import http from './http-common';

class SalonService{
  
    addService(Salon){
        return http.post("newsalonservice",Salon);
    }
  
    getAllServices(){
        return http.get("allservices");
    }
    removeService(serviceId){
        return http.delete("salon/"+serviceId);
    }
    updateService(Salon){
        return http.put("updateservice",Salon);
    }
    getServiceByPrice() {
        return http.get("servicesbyprice");
    }
}

export default new SalonService();