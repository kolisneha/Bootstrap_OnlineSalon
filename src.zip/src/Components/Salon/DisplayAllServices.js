import { useEffect, useState } from "react";
import Modal from "react-modal/lib/components/Modal";
import SalonService from "../../Services/SalonService";

import React from 'react';

function DisplayAllServices(){

    const [Services, setServices] = useState(
        [
            {
                "serviceId": "",
                "serviceName": "",
                "price":"",
                "discount":""
                
            }
        ]
    );

    const [editProfile, setEditProfile] = useState(
        {
            "serviceName": "",
            "price":"",
            "discount":""
        }
    );

    const [isEdit, setIsEdit] = useState(false);
    const [msg, setMsg] = useState(undefined);
    const [errorMsg, setErrorMsg] = useState(undefined);
   
    useEffect(() => {
        loadAllServices();
    }, []);


    const deleteHandler = (id) => {
        console.log("Service delete called");
        SalonService.removeService(id)
            .then((response) => {
                console.log("deleted:")
                console.log(response.data);
                setMsg("Service got Deleted successfully :)");
                setErrorMsg(undefined);
                loadAllServices();
            })
            .catch((error) => {
                console.log(error);
                setErrorMsg("Fail to Delete Service !");
            setMsg(undefined);
            })
    }

    const submitHandle = (e)=>{

        console.log(editProfile);
        SalonService.updateService(editProfile)
        .then((response)=>{
            console.log(response.data);
            setMsg("Service Edited successfully !");
            setErrorMsg(undefined);
            setIsEdit(false);
            loadAllServices();

        })
        .catch((error)=>{
            console.log(error.response);
            setErrorMsg("Fail to Edit Profile !");
            setMsg(undefined);
            setIsEdit(false);
        })
    };


    const updateHandler = (service) => {
        console.log("updating" + JSON.stringify(service));
        setEditProfile(service);
        setIsEdit(true);
    };

    const changeHandle = (e) => {
        const value = e.target.value;
        const name = e.target.name;
        setEditProfile(prevData=>({...prevData,[name]:value}));
        //console.log(value);
    };

    const updateService = (
        <><div className="editprofile">
        <h3>Edit Service.</h3>
        {msg && <h5>{msg}</h5>}
        {errorMsg && <h5>{errorMsg}</h5>}
        {/* {JSON.stringify(editEmployee)} */}
        <form onSubmit={submitHandle}>
                <label>Service Name:</label>
                <input type="text" name="serviceName" value={editProfile.serviceName} onChange={changeHandle}></input>
                <label>Price:</label>
                <input type="number" name="price" value={editProfile.price} onChange={changeHandle}></input><br></br>
                <label>Discount:</label>
                <input type="number" name="discount" value={editProfile.discount} onChange={changeHandle}></input>
               
                <input type="submit"/>
            </form>
            </div>
        </>
    );

    const loadAllServices = ()=>{
        SalonService.getAllServices()
        .then((response)=>{
            console.log(response.data);
            setServices(response.data);
            setErrorMsg(undefined);
        })
        .catch((error)=>{ 
            console.log(error);
            setErrorMsg("Server Unavailable....Try Again later !");
        })
    };

    const servicesTableElement = (
        <>
      
            <div className="displayservices">  
            <h3>Display all Services</h3>
            {msg && <h5 className="alert alert-success">{msg}</h5>}
            {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}
            <table className="table table-striped table-bordered">
                <thead>
                    <tr>
                        
                        <th>serviceName</th>
                        <th>price</th>
                        <th>discount</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        Services.map((service, index) => (
                                <> 
                                <tr key={service.serviceId}>
                                    <td>{service.serviceName}</td>
                                    <td>{service.price}</td>
                                    <td>{service.discount}</td>
                                    <td>
                                    <input className="btn btn-info" id="edit" type="button" value="Edit Profile" onClick={() => updateHandler(service)}></input>
                                    &nbsp;&nbsp;&nbsp;&nbsp; 
                                    <input className="btn btn-danger" id="delete" type="button" value="Delete Service" onClick={() => deleteHandler(service.serviceId)}></input>
                                    </td>
                                </tr>
                                </>
                            )
                        )
                    }
                </tbody>
            </table>
          
            </div>
         
        </>
    );

    return  isEdit? updateService : servicesTableElement
}

export default DisplayAllServices;