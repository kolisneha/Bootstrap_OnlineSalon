import { useState } from "react";
import SalonService from "../../Services/SalonService";


const AddService=()=>{

    const [service , SetService]=useState(
        {
            "serviceName":"",
            "price":"",
            "discount":""       
        }
    )

    const [isEdit, setIsEdit] = useState(false);
    const [msg, setMsg] = useState(undefined);
    const [errorMsg, setErrorMsg] = useState(undefined);

    const handleChange=(e)=>{
        const name=e.target.name;
        const value=e.target.value;
        SetService((preService)=>({
            ...preService,[name]:value
        }))
    };

    const handleSubmit=(e)=>{
        e.preventDefault();
        console.log(service);
        SalonService.addService(service)
        .then((Response)=>{
            console.log(Response.data);
            setMsg("service got Added Successfully :)");
            setErrorMsg(undefined);
        })
        .catch((error)=>{
            console.log(error);
            setErrorMsg("Failed to Add service !");
            setMsg(undefined);
         })
    }

    return(
        <><div className="addservice">
            <h3> Add New Service here!!</h3>
            {msg && <h5 className="alert alert-success">{msg}</h5>}
            {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}
            <form onSubmit={handleSubmit}>
                
                <label>Service Name:</label>
                <input type="text" name="serviceName" value={service.serviceName} onChange={handleChange} required></input><br></br>
                <label> Price:</label>
                <input type="number" name="price"value={service.price} onChange={handleChange} required></input><br></br>
                <label>Discount:</label>
                <input type="number" name="discount"value={service.discount} onChange={handleChange} required></input><br></br>

                <input type="submit"></input>
            </form>
            </div>
        </>
    );

}

export default AddService;