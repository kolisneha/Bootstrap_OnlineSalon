import { useEffect, useState } from "react";
import SalonService from "../../Services/SalonService";


function ServicesByPrice(){

    const [Services, setServices] = useState(
        [
            {
                "serviceId": "",
                "serviceName": "",
                "price":"",
                "discount":""
                
            }
        ]
    );

    const [isEdit, setIsEdit] = useState(false);
    const [msg, setMsg] = useState(undefined);
    const [errorMsg, setErrorMsg] = useState(undefined);

    useEffect(() => {
        loadAllServices();
    }, []);
   
    const loadAllServices = ()=>{
        SalonService.getServiceByPrice()
        .then((response)=>{
            console.log(response.data);
            setServices(response.data);
            setErrorMsg(undefined);
        })
        .catch((error)=>{ 
            console.log(error);
            setErrorMsg("Server Unavailable....Try Again later !");
        })
    };
    const servicesTableElement = (
        <>
           <div className="displayservices">
            <h3>All Services Sorted by Prices</h3>
            {msg && <h5 className="alert alert-success">{msg}</h5>}
            {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}
            
            <table className="table table-striped table-bordered">
                <thead>
                    <tr>
                        
                        <th>serviceName</th>
                        <th>price</th>
                        <th>discount</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        Services.map((service, index) => (
                                <> 
                                <tr key={service.serviceId}>
                                    <td>{service.serviceName}</td>
                                    <td>{service.price}</td>
                                    <td>{service.discount}</td>
                                   
                                </tr>
                                </>
                            )
                        )
                    }
                </tbody>
            </table>
            </div>
        </>
    );
    return servicesTableElement;
}

export default ServicesByPrice;
